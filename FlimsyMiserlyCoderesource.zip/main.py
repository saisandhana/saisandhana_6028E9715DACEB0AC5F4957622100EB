num=int(input('enter a number'))
f=1
for i in range(1,num+1):
  f=f*i
print ('factorial of', num, '=',f)